var searchData=
[
  ['matrix_0',['matrix',['../class_rational_matrix.html#a42e947cc7392a6620f215c727edff664',1,'RationalMatrix']]]
];
