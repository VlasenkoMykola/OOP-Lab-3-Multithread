var searchData=
[
  ['is0_0',['is0',['../classrational.html#a6b9554a840df93d6071f12dcbfa5abbf',1,'rational']]],
  ['is1_1',['is1',['../classrational.html#ac4b23edb5ac8c8ea454964aa7f1c750a',1,'rational']]]
];
