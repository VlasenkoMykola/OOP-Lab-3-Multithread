var searchData=
[
  ['testverbose_0',['testverbose',['../unittest_8h.html#ae7429bcaff859cf0fc53f0eaebb41548',1,'unittest.h']]]
];
